const express = require('express');
const router = express.Router();
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const db = require('../db');
require('dotenv').config();

// Super Admin Login (static credentials from .env)
router.post('/super-admin/login', (req, res) => {
  const { email, password } = req.body;

  if (
    email !== process.env.SUPER_ADMIN_EMAIL ||
    password !== process.env.SUPER_ADMIN_PASSWORD
  ) {
    return res.status(401).json({ error: 'Invalid credentials' });
  }

  const token = jwt.sign(
    { role: 'super_admin', email },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );

  res.json({ token });
});

// Org Admin Signup
router.post('/admin/signup', async (req, res) => {
  const { email, password, org_id } = req.body;

  // Check org exists
  const org = db.prepare('SELECT * FROM organizations WHERE id = ?').get(org_id);
  if (!org) return res.status(400).json({ error: 'Organization not found' });

  // Hash password
  const password_hash = await bcrypt.hash(password, 10);

  try {
    db.prepare(
      'INSERT INTO users (email, password_hash, role, org_id) VALUES (?, ?, ?, ?)'
    ).run(email, password_hash, 'org_admin', org_id);

    res.json({ message: 'Signup successful' });
  } catch (err) {
    res.status(400).json({ error: 'Email already exists' });
  }
});

// Org Admin Login
router.post('/admin/login', async (req, res) => {
  const { email, password } = req.body;

  const user = db.prepare('SELECT * FROM users WHERE email = ?').get(email);
  if (!user) return res.status(401).json({ error: 'Invalid credentials' });

  const valid = await bcrypt.compare(password, user.password_hash);
  if (!valid) return res.status(401).json({ error: 'Invalid credentials' });

  const token = jwt.sign(
    { id: user.id, email: user.email, role: user.role, org_id: user.org_id },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  );

  res.json({ token, org_id: user.org_id });
});

module.exports = router;