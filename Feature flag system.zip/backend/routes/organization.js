const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/auth');

// Only super admin can create and view orgs
router.post('/', verifyToken, requireRole('super_admin'), (req, res) => {
  const { name } = req.body;
  if (!name) return res.status(400).json({ error: 'Name is required' });

  try {
    db.prepare('INSERT INTO organization (name) VALUES (?)').run(name);
    res.json({ message: 'Organization created' });
  } catch (err) {
    res.status(400).json({ error: 'Organization name already exists' });
  }
});

router.get('/', verifyToken, requireRole('super_admin'), (req, res) => {
  const orgs = db.prepare('SELECT * FROM organization').all();
  res.json(orgs);
});

// Public route — no auth needed (for signup dropdowns and user page)
router.get('/public', (req, res) => {
  const orgs = db.prepare('SELECT id, name FROM organization').all();
  res.json(orgs);
});

module.exports = router;