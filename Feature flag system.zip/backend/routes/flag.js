const express = require('express');
const router = express.Router();
const db = require('../db');
const { verifyToken, requireRole } = require('../middleware/auth');

// Check feature flag — public endpoint for end users
router.get('/check', (req, res) => {
  const { org_id, feature_key } = req.query;

  const flag = db.prepare(
    'SELECT * FROM feature_flags WHERE org_id = ? AND feature_key = ?'
  ).get(org_id, feature_key);

  if (!flag) return res.json({ exists: false, is_enabled: false });

  res.json({ exists: true, is_enabled: flag.is_enabled === 1 });
});

// All below routes: org admin only
router.use(verifyToken, requireRole('org_admin'));

// Get all flags for admin's org
router.get('/', (req, res) => {
  const flags = db.prepare(
    'SELECT * FROM feature_flags WHERE org_id = ?'
  ).all(req.user.org_id);
  res.json(flags);
});

// Create a flag
router.post('/', (req, res) => {
  const { feature_key, is_enabled } = req.body;

  try {
    db.prepare(
      'INSERT INTO feature_flags (feature_key, is_enabled, org_id) VALUES (?, ?, ?)'
    ).run(feature_key, is_enabled ? 1 : 0, req.user.org_id);
    res.json({ message: 'Flag created' });
  } catch (err) {
    res.status(400).json({ error: 'Could not create flag' });
  }
});

// Enable / Disable a flag
router.patch('/:id', (req, res) => {
  const { is_enabled } = req.body;

  // Make sure flag belongs to this admin's org
  const flag = db.prepare(
    'SELECT * FROM feature_flags WHERE id = ? AND org_id = ?'
  ).get(req.params.id, req.user.org_id);

  if (!flag) return res.status(404).json({ error: 'Flag not found' });

  db.prepare(
    'UPDATE feature_flags SET is_enabled = ? WHERE id = ?'
  ).run(is_enabled ? 1 : 0, req.params.id);

  res.json({ message: 'Flag updated' });
});

// Delete a flag
router.delete('/:id', (req, res) => {
  const flag = db.prepare(
    'SELECT * FROM feature_flags WHERE id = ? AND org_id = ?'
  ).get(req.params.id, req.user.org_id);

  if (!flag) return res.status(404).json({ error: 'Flag not found' });

  db.prepare('DELETE FROM feature_flags WHERE id = ?').run(req.params.id);
  res.json({ message: 'Flag deleted' });
});

module.exports = router;